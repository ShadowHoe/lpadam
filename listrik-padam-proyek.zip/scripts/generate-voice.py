#!/usr/bin/env python3
"""Membuat voice over (text to speech) per adegan dengan Microsoft Edge TTS (gratis, perlu internet).
Hasil: public/voice/s0.mp3 ... dan src/ListrikPadam/durations.json (dipakai agar durasi video pas dengan suara)."""
import asyncio
import json
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
SCRIPT = ROOT / "src/ListrikPadam/script.json"
OUT = ROOT / "public/voice"
DUR = ROOT / "src/ListrikPadam/durations.json"

VOICE = "id-ID-ArdiNeural"  # suara pria. Untuk suara wanita: "id-ID-GadisNeural"
RATE = "+0%"  # mis. "+8%" untuk lebih cepat, "-5%" untuk lebih lambat


def ensure(module, pip_name):
    try:
        __import__(module)
    except ImportError:
        print(f"Memasang {pip_name} ...")
        cmd = [sys.executable, "-m", "pip", "install", "-q", pip_name]
        try:
            subprocess.check_call(cmd)
        except subprocess.CalledProcessError:
            subprocess.check_call(cmd + ["--break-system-packages"])


async def main():
    ensure("edge_tts", "edge-tts")
    ensure("mutagen", "mutagen")
    import edge_tts
    from mutagen.mp3 import MP3

    OUT.mkdir(parents=True, exist_ok=True)
    items = json.loads(SCRIPT.read_text(encoding="utf-8"))
    durations = {}
    for it in items:
        path = OUT / f"{it['id']}.mp3"
        await edge_tts.Communicate(it["narration"], VOICE, rate=RATE).save(str(path))
        durations[it["id"]] = round(MP3(str(path)).info.length, 2)
        print(f"{it['id']}: {durations[it['id']]} detik")
    DUR.write_text(json.dumps(durations, indent=2), encoding="utf-8")
    print(f"Total narasi: {sum(durations.values()):.1f} detik. Selesai.")


if __name__ == "__main__":
    asyncio.run(main())
