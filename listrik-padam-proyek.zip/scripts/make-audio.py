#!/usr/bin/env python3
"""Membuat musik latar ambient + efek suara 'listrik padam'.
Tanpa internet, hanya library bawaan Python. Hasil: public/music.wav dan public/blackout.wav"""
import math
import random
import wave
from array import array
from pathlib import Path

SR = 16000
ROOT = Path(__file__).resolve().parent.parent
PUBLIC = ROOT / "public"


def save(path, samples):
    data = array("h", (int(max(-1.0, min(1.0, s)) * 32767) for s in samples))
    with wave.open(str(path), "wb") as w:
        w.setnchannels(1)
        w.setsampwidth(2)
        w.setframerate(SR)
        w.writeframes(data.tobytes())


def music(seconds=125):
    freqs = [55.0, 110.0, 164.81, 220.0, 261.63, 329.63]
    two_pi = 2 * math.pi
    out = []
    for i in range(seconds * SR):
        t = i / SR
        s = 0.0
        for k, fq in enumerate(freqs):
            amp = 0.5 + 0.5 * math.sin(two_pi * t / (14 + k * 4) + k * 1.3)
            s += amp * (math.sin(two_pi * fq * t) + 0.3 * math.sin(two_pi * fq * 2.003 * t))
        env = min(1.0, t / 3, (seconds - t) / 3)
        out.append(s / 9.0 * env)
    return out


def blackout():
    random.seed(7)
    n = int(SR * 1.2)
    out = []
    phase = 0.0
    for i in range(n):
        t = i / SR
        freq = 700 * math.exp(-t * 3.6) + 30
        phase += 2 * math.pi * freq / SR
        env = math.exp(-t * 2.4)
        s = 0.7 * math.sin(phase) * env + 0.2 * math.sin(phase * 0.5) * env
        if t < 0.06:
            s += (random.random() * 2 - 1) * 0.6 * (1 - t / 0.06)
        out.append(s * 0.9)
    return out


if __name__ == "__main__":
    PUBLIC.mkdir(parents=True, exist_ok=True)
    print("Membuat efek suara...")
    save(PUBLIC / "blackout.wav", blackout())
    print("Membuat musik latar (sekitar 20-40 detik)...")
    save(PUBLIC / "music.wav", music())
    print("Selesai: public/music.wav, public/blackout.wav")
