import React from "react";
import {
  AbsoluteFill,
  Audio,
  Easing,
  Sequence,
  interpolate,
  interpolateColors,
  spring,
  staticFile,
  useCurrentFrame,
  useVideoConfig,
} from "remotion";
import { BLACKOUT_FRAME, HANDLE, TOTAL_FRAMES, scenes } from "./timeline";
import type { SceneData } from "./timeline";

/* ---------- Gaya (navy tua + kuning, vektor datar) ---------- */
const YELLOW = "#FFD93D";
const NAVY = "#0D1B45";
const NAVY_DARK = "#050A1A";
const PANEL = "#13224F";
const LINE = "#2E3F78";
const WHITE = "#EAF0FF";
const RED = "#FF5A5F";
const ORANGE = "#FF9F43";
const GREEN = "#7ED957";
const TEAL = "#3DD6D0";
const GRAY = "#6B7BA6";
const DARK = "#0A1330";
const FONT = "'Inter','Segoe UI','Helvetica Neue',Arial,sans-serif";

const clamp = { extrapolateLeft: "clamp", extrapolateRight: "clamp" } as const;

const rand = (n: number) => {
  const x = Math.sin(n * 127.1 + 311.7) * 43758.5453;
  return x - Math.floor(x);
};

const pop = (frame: number, fps: number, delay: number) =>
  spring({ frame: Math.max(0, frame - delay), fps, config: { damping: 11, stiffness: 150 } });

/* ---------- Status listrik (1 = nyala, 0 = padam) ---------- */
export const powerAt = (frame: number) => {
  const start = BLACKOUT_FRAME - 20;
  if (frame < start) return 1;
  if (frame < BLACKOUT_FRAME) return Math.floor((frame - start) / 4) % 2 === 0 ? 0.25 : 1;
  return 0;
};

/* ---------- Latar: langit, bintang, bulan ---------- */
const STARS = Array.from({ length: 46 }, (_, i) => ({
  x: rand(i + 1) * 1080,
  y: rand(i + 77) * 1150,
  r: 1.5 + rand(i + 9) * 2.5,
  ph: rand(i + 33) * 6.28,
}));

const Background: React.FC = () => {
  const f = useCurrentFrame();
  const p = powerAt(f);
  const bg = interpolateColors(p, [0, 1], [NAVY_DARK, NAVY]);
  return (
    <AbsoluteFill style={{ backgroundColor: bg }}>
      <svg width={1080} height={1920} style={{ position: "absolute", left: 0, top: 0 }}>
        {STARS.map((s, i) => (
          <circle
            key={i}
            cx={s.x}
            cy={s.y}
            r={s.r}
            fill="#FFFFFF"
            opacity={(1 - p) * (0.3 + 0.7 * Math.abs(Math.sin(f / 25 + s.ph)))}
          />
        ))}
        <circle cx={905} cy={190} r={110} fill="#9FB4FF" opacity={(1 - p) * 0.08} />
        <circle cx={905} cy={190} r={52} fill="#E9EFFF" opacity={(1 - p) * 0.95} />
        <circle cx={926} cy={178} r={46} fill={bg} opacity={1 - p} />
      </svg>
    </AbsoluteFill>
  );
};

/* ---------- Kota yang bersambung antar adegan ---------- */
type B = { x: number; w: number; h: number; i: number };
const BUILDINGS: B[] = (() => {
  const a: B[] = [];
  let x = -60;
  let i = 0;
  while (x < 2500) {
    const w = 100 + rand(i + 3) * 120;
    const h = 150 + rand(i + 21) * 270;
    a.push({ x, w, h, i });
    x += w + 6 + rand(i + 5) * 16;
    i++;
  }
  return a;
})();
const SKY_H = 520;
const BASE = 480;

const Skyline: React.FC = () => {
  const f = useCurrentFrame();
  const p = powerAt(f);
  const pan = f * 0.22;
  const lit = interpolateColors(p, [0, 1], ["#101C40", YELLOW]);
  const body = interpolateColors(p, [0, 1], ["#0A1330", "#182A5E"]);
  return (
    <svg width={1080} height={SKY_H} style={{ position: "absolute", left: 0, bottom: 0 }}>
      <g transform={`translate(${-pan} 0)`}>
        {BUILDINGS.map((b) => {
          const top = BASE - b.h;
          const cols = Math.max(2, Math.floor((b.w - 22) / 30));
          const rows = Math.floor((b.h - 30) / 46);
          const cell = (b.w - 20) / cols;
          const wins: React.ReactNode[] = [];
          for (let r = 0; r < rows; r++) {
            for (let c = 0; c < cols; c++) {
              const on = rand(b.i * 131 + r * 17 + c * 7) > 0.38;
              wins.push(
                <rect
                  key={`${r}-${c}`}
                  x={b.x + 10 + c * cell + (cell - 16) / 2}
                  y={top + 18 + r * 46}
                  width={16}
                  height={24}
                  rx={3}
                  fill={on ? lit : "#101C40"}
                />
              );
            }
          }
          return (
            <g key={b.i}>
              <rect x={b.x} y={top} width={b.w} height={b.h + 40} rx={6} fill={body} />
              {rand(b.i + 400) > 0.65 ? (
                <rect x={b.x + b.w / 2 - 3} y={top - 36} width={6} height={36} fill={LINE} />
              ) : null}
              {wins}
            </g>
          );
        })}
      </g>
      <rect x={0} y={BASE} width={1080} height={SKY_H - BASE} fill="#070D22" />
    </svg>
  );
};

/* ---------- Teks: label pil + caption kuning ---------- */
const Tag: React.FC<{ text: string }> = ({ text }) => {
  const f = useCurrentFrame();
  const { fps } = useVideoConfig();
  const s = pop(f, fps, 0);
  return (
    <div style={{ position: "absolute", top: 150, left: 0, right: 0, display: "flex", justifyContent: "center" }}>
      <div
        style={{
          background: YELLOW,
          color: NAVY,
          fontWeight: 900,
          fontSize: 46,
          letterSpacing: 3,
          padding: "16px 44px",
          borderRadius: 999,
          transform: `scale(${s})`,
          boxShadow: "0 8px 0 rgba(0,0,0,0.35)",
        }}
      >
        {text}
      </div>
    </div>
  );
};

const Caption: React.FC<{ text: string }> = ({ text }) => {
  const f = useCurrentFrame();
  const { fps } = useVideoConfig();
  const words = text.split(" ");
  return (
    <div
      style={{
        position: "absolute",
        left: 60,
        right: 60,
        top: 1010,
        height: 380,
        display: "flex",
        flexWrap: "wrap",
        justifyContent: "center",
        alignContent: "center",
        gap: "0 22px",
      }}
    >
      {words.map((w, i) => {
        const s = pop(f, fps, 8 + i * 3);
        return (
          <span
            key={i}
            style={{
              display: "inline-block",
              fontSize: 84,
              fontWeight: 900,
              lineHeight: 1.18,
              color: YELLOW,
              opacity: Math.min(1, s * 1.5),
              transform: `translateY(${(1 - s) * 40}px) scale(${0.9 + 0.1 * s})`,
              textShadow: "0 6px 0 rgba(0,0,0,0.35)",
            }}
          >
            {w}
          </span>
        );
      })}
    </div>
  );
};

const Stage: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const f = useCurrentFrame();
  const o = interpolate(f, [0, 10], [0, 1], clamp);
  const y = interpolate(f, [0, 14], [30, 0], { ...clamp, easing: Easing.out(Easing.cubic) });
  return (
    <svg
      viewBox="0 0 1080 700"
      width={1080}
      height={700}
      style={{ position: "absolute", left: 0, top: 290, opacity: o, transform: `translateY(${y}px)` }}
    >
      {children}
    </svg>
  );
};

type IllProps = { d: number; from: number };

/* ================= ILUSTRASI ================= */

/* 0 - Lampu menyala lalu padam */
const IllBulb: React.FC<IllProps> = ({ from }) => {
  const f = useCurrentFrame();
  const p = powerAt(from + f);
  const glass = interpolateColors(p, [0, 1], ["#1B2A5A", YELLOW]);
  const pulse = 1 + 0.015 * Math.sin(f / 5);
  const rays = Array.from({ length: 12 }, (_, i) => {
    const a = (i / 12) * Math.PI * 2;
    const r1 = 200;
    const r2 = 250 + 14 * Math.sin(f / 4 + i);
    return (
      <line
        key={i}
        x1={540 + Math.cos(a) * r1}
        y1={270 + Math.sin(a) * r1}
        x2={540 + Math.cos(a) * r2}
        y2={270 + Math.sin(a) * r2}
        stroke={YELLOW}
        strokeWidth={10}
        strokeLinecap="round"
        opacity={p}
      />
    );
  });
  return (
    <g>
      <line x1={540} y1={-20} x2={540} y2={110} stroke={GRAY} strokeWidth={8} />
      <circle cx={540} cy={270} r={330 * p} fill={YELLOW} opacity={0.1 * p} />
      <circle cx={540} cy={270} r={250 * p} fill={YELLOW} opacity={0.14 * p} />
      {rays}
      <g transform={`translate(540 270) scale(${pulse}) translate(-540 -270)`}>
        <circle cx={540} cy={270} r={150} fill={glass} />
        <rect x={480} y={380} width={120} height={64} fill={glass} />
        <path d="M470 300 Q480 380 480 400 L600 400 Q600 380 610 300 Z" fill={glass} />
        <path
          d="M495 330 L515 250 L540 310 L565 250 L585 330"
          fill="none"
          stroke={p > 0.5 ? ORANGE : GRAY}
          strokeWidth={10}
          strokeLinejoin="round"
          strokeLinecap="round"
        />
        <path d="M450 220 Q470 160 530 140" fill="none" stroke="#FFFFFF" strokeWidth={14} strokeLinecap="round" opacity={0.35} />
      </g>
      <rect x={470} y={440} width={140} height={28} rx={10} fill={GRAY} />
      <rect x={480} y={474} width={120} height={28} rx={10} fill="#8696C2" />
      <rect x={500} y={508} width={80} height={26} rx={12} fill={GRAY} />
    </g>
  );
};

/* 1 - Lampu lalu lintas mati + mobil bingung */
const Car: React.FC<{ x: number; y: number; color: string; flip?: boolean }> = ({ x, y, color, flip }) => (
  <g transform={`translate(${x} ${y})${flip ? " translate(220 0) scale(-1 1)" : ""}`}>
    <polygon points="220,50 380,18 380,92 220,70" fill={YELLOW} opacity={0.22} />
    <rect x={0} y={32} width={220} height={52} rx={16} fill={color} />
    <path d="M44 34 L72 2 L152 2 L184 34 Z" fill={color} />
    <path d="M62 32 L80 10 L108 10 L108 32 Z" fill="#CFE0FF" />
    <path d="M118 32 L118 10 L146 10 L168 32 Z" fill="#CFE0FF" />
    <circle cx={56} cy={86} r={22} fill={DARK} stroke={GRAY} strokeWidth={6} />
    <circle cx={164} cy={86} r={22} fill={DARK} stroke={GRAY} strokeWidth={6} />
    <rect x={204} y={46} width={16} height={14} rx={4} fill={YELLOW} />
  </g>
);

const IllStreet: React.FC<IllProps> = () => {
  const f = useCurrentFrame();
  const { fps } = useVideoConfig();
  const red = interpolate(f, [0, 10], [1, 0], clamp);
  const ax = interpolate(f, [4, 40], [-300, 290], { ...clamp, easing: Easing.out(Easing.cubic) });
  const bx = interpolate(f, [10, 46], [1300, 570], { ...clamp, easing: Easing.out(Easing.cubic) });
  const bang = pop(f, fps, 44);
  const blink = Math.floor(f / 8) % 2 === 0 ? 1 : 0.4;
  return (
    <g>
      <rect x={525} y={400} width={30} height={125} fill={GRAY} />
      <rect x={470} y={10} width={140} height={400} rx={34} fill="#1B2A52" stroke={LINE} strokeWidth={8} />
      <circle cx={540} cy={90} r={44} fill={interpolateColors(red, [0, 1], [DARK, RED])} stroke={LINE} strokeWidth={6} />
      <circle cx={540} cy={210} r={44} fill={DARK} stroke={LINE} strokeWidth={6} />
      <circle cx={540} cy={330} r={44} fill={DARK} stroke={LINE} strokeWidth={6} />
      <Car x={ax} y={525} color={ORANGE} />
      <Car x={bx} y={525} color={TEAL} flip />
      <g opacity={bang * blink} transform={`translate(430 470) scale(${bang})`}>
        <text x={0} y={0} fontSize={110} fontWeight={900} fill={RED} textAnchor="middle">
          !
        </text>
      </g>
      <g opacity={bang * blink} transform={`translate(650 470) scale(${bang})`}>
        <text x={0} y={0} fontSize={110} fontWeight={900} fill={RED} textAnchor="middle">
          !
        </text>
      </g>
    </g>
  );
};

/* 2 - Baterai ponsel habis + sinyal hilang */
const IllPhone: React.FC<IllProps> = ({ d }) => {
  const f = useCurrentFrame();
  const pct = Math.round(interpolate(f, [8, d - 30], [100, 1], clamp));
  const col = pct < 20 ? RED : GREEN;
  const bars = Math.round(interpolate(f, [10, d - 40], [4, 0], clamp));
  const wave = interpolate(f, [10, d - 20], [1, 0], clamp);
  return (
    <g>
      <rect x={360} y={10} width={360} height={650} rx={56} fill="#0B1534" stroke={YELLOW} strokeWidth={10} />
      <rect x={470} y={28} width={140} height={22} rx={11} fill={LINE} />
      {[0, 1, 2, 3].map((i) => (
        <rect key={i} x={420 + i * 24} y={120 - (i + 1) * 12} width={16} height={(i + 1) * 12} rx={4} fill={i < bars ? WHITE : LINE} />
      ))}
      {bars === 0 ? (
        <text x={540} y={118} fontSize={54} fontWeight={900} fill={RED}>
          ×
        </text>
      ) : null}
      <rect x={450} y={230} width={180} height={90} rx={14} fill="none" stroke={WHITE} strokeWidth={8} />
      <rect x={632} y={252} width={14} height={46} rx={4} fill={WHITE} />
      <rect x={460} y={240} width={Math.max(6, 160 * (pct / 100))} height={70} rx={8} fill={col} />
      <text x={540} y={450} fontSize={130} fontWeight={900} fill={WHITE} textAnchor="middle">
        {pct}%
      </text>
      {/* menara sinyal */}
      <path d="M860 640 L900 270 L940 640 M872 520 L928 520 M880 430 L920 430" fill="none" stroke={WHITE} strokeWidth={8} strokeLinejoin="round" />
      <circle cx={900} cy={250} r={16} fill={ORANGE} />
      {[40, 70, 100].map((r, i) => (
        <circle key={r} cx={900} cy={250} r={r} fill="none" stroke={ORANGE} strokeWidth={6} opacity={wave * (0.8 - i * 0.2) * (0.6 + 0.4 * Math.sin(f / 5 - i))} />
      ))}
      {/* colokan tanpa listrik */}
      <rect x={110} y={270} width={150} height={100} rx={22} fill={WHITE} />
      <rect x={140} y={230} width={20} height={44} rx={6} fill={GRAY} />
      <rect x={210} y={230} width={20} height={44} rx={6} fill={GRAY} />
      <path d="M185 370 Q185 470 120 500" fill="none" stroke={GRAY} strokeWidth={14} strokeLinecap="round" />
      <circle cx={185} cy={320} r={90} fill="none" stroke={RED} strokeWidth={10} />
      <line x1={121} y1={256} x2={249} y2={384} stroke={RED} strokeWidth={10} />
    </g>
  );
};

/* 3 - Kulkas (makanan basi) + keran air berhenti */
const IllKitchen: React.FC<IllProps> = ({ d }) => {
  const f = useCurrentFrame();
  const rot = interpolate(f, [10, d - 20], [0, 1], clamp);
  const c = (fresh: string, rotten: string) => interpolateColors(rot, [0, 1], [fresh, rotten]);
  const stream = interpolate(f, [20, 70], [1, 0], clamp);
  const stink = Math.max(0, rot - 0.35) * 1.5;
  const rise = (f * 1.4) % 36;
  return (
    <g>
      <rect x={150} y={10} width={330} height={660} rx={34} fill="#DCE7FF" />
      <rect x={175} y={35} width={280} height={610} rx={20} fill="#0B1534" />
      {[200, 360, 520].map((y) => (
        <rect key={y} x={175} y={y} width={280} height={10} fill="#9FB4E8" />
      ))}
      <circle cx={235} cy={160} r={38} fill={c(RED, "#6B7A33")} />
      <rect x={305} y={120} width={70} height={80} rx={10} fill={c(WHITE, "#A7B07A")} />
      <polygon points="385,200 445,200 445,150" fill={c(YELLOW, "#8E8A3A")} />
      <ellipse cx={250} cy={325} rx={55} ry={35} fill={c(ORANGE, "#7A6A3A")} />
      <circle cx={350} cy={320} r={38} fill={c("#FF7A59", "#5E6B2E")} />
      <rect x={395} y={290} width={50} height={70} rx={10} fill={c(TEAL, "#4C7F5A")} />
      <rect x={200} y={460} width={110} height={60} rx={14} fill={c("#B58CFF", "#6B6A45")} />
      <circle cx={390} cy={480} r={40} fill={c(GREEN, "#6C7A2A")} />
      {[240, 320, 400].map((x, i) => (
        <path
          key={x}
          d={`M${x} ${300 - rise} q 14 -22 0 -44 q -14 -22 0 -44`}
          fill="none"
          stroke={GREEN}
          strokeWidth={7}
          strokeLinecap="round"
          opacity={stink * (0.9 - i * 0.15)}
          transform={`translate(0 ${-i * 30})`}
        />
      ))}
      {/* keran */}
      <path d="M720 -10 L720 120 Q720 160 760 160 L836 160" fill="none" stroke={GRAY} strokeWidth={34} strokeLinecap="round" />
      <rect x={826} y={150} width={46} height={30} rx={8} fill={GRAY} />
      <rect x={839} y={182} width={20} height={320 * stream} fill={TEAL} />
      <circle cx={849} cy={200 + ((f * 7) % 280)} r={9} fill={TEAL} opacity={stream < 0.05 && f < d - 40 ? 0.9 : 0} />
      <path d="M780 500 L918 500 L900 650 L798 650 Z" fill="none" stroke={WHITE} strokeWidth={8} strokeLinejoin="round" />
      <rect x={806} y={590} width={86} height={52} fill={TEAL} opacity={0.85} />
    </g>
  );
};

/* 4 - Rumah sakit, genset habis, detak jantung datar */
const ecgPath = (w: number, beatsUntil: number) => {
  let dd = "M0 0";
  let x = 0;
  const beat = 110;
  while (x < w) {
    if (x < beatsUntil && x + beat <= w) {
      dd += ` L${x + 20} 0 L${x + 35} -14 L${x + 45} 0 L${x + 55} 0 L${x + 62} -70 L${x + 72} 50 L${x + 82} 0 L${x + beat} 0`;
      x += beat;
    } else {
      dd += ` L${w} 0`;
      x = w;
    }
  }
  return dd;
};

const IllHospital: React.FC<IllProps> = ({ d }) => {
  const f = useCurrentFrame();
  const gen = interpolate(f, [10, d - 25], [1, 0], clamp);
  const prog = interpolate(f, [8, d - 18], [0, 1], clamp);
  const winOn = gen > 0.05;
  const win = (x: number, y: number) => (
    <rect key={`${x}-${y}`} x={x} y={y} width={50} height={60} rx={8} fill={winOn ? YELLOW : "#0F1B3F"} />
  );
  return (
    <g>
      <rect x={240} y={70} width={600} height={36} rx={14} fill="#B7C8F2" />
      <rect x={260} y={90} width={560} height={300} rx={20} fill="#DCE7FF" />
      <rect x={520} y={165} width={40} height={70} fill={RED} />
      <rect x={505} y={180} width={70} height={40} fill={RED} />
      {[290, 370, 670, 750].map((x) => (
        <g key={x}>{[140, 250].map((y) => win(x, y))}</g>
      ))}
      <rect x={500} y={300} width={80} height={90} rx={10} fill="#0F1B3F" />
      <text x={130} y={100} fontSize={34} fontWeight={900} fill={WHITE} textAnchor="middle">
        GENSET
      </text>
      <rect x={40} y={118} width={180} height={44} rx={22} fill="none" stroke={WHITE} strokeWidth={6} />
      <rect x={46} y={124} width={Math.max(0, 168 * gen)} height={32} rx={16} fill={gen < 0.3 ? RED : YELLOW} />
      <rect x={120} y={430} width={840} height={240} rx={30} fill="#0B1534" stroke={LINE} strokeWidth={8} />
      <g transform="translate(150 565)">
        <path
          d={ecgPath(780, 330)}
          fill="none"
          stroke={prog > 0.88 ? RED : GREEN}
          strokeWidth={8}
          strokeLinejoin="round"
          strokeLinecap="round"
          pathLength={1}
          strokeDasharray={1}
          strokeDashoffset={1 - prog}
        />
      </g>
    </g>
  );
};

/* 5 - Pom bensin, ATM, toko */
const IllShops: React.FC<IllProps> = () => {
  const f = useCurrentFrame();
  const { fps } = useVideoConfig();
  const cards = [40, 380, 720];
  const labels = ["POM BENSIN", "ATM", "TOKO"];
  return (
    <g>
      {cards.map((x, i) => (
        <rect key={x} x={x} y={40} width={320} height={520} rx={36} fill={PANEL} stroke={LINE} strokeWidth={6} />
      ))}
      {/* pom bensin */}
      <rect x={110} y={410} width={180} height={24} rx={8} fill={GRAY} />
      <rect x={130} y={110} width={140} height={300} rx={18} fill={ORANGE} />
      <rect x={150} y={135} width={100} height={70} rx={10} fill="#0B1534" />
      <text x={200} y={185} fontSize={44} fontWeight={900} fill={RED} textAnchor="middle">
        0
      </text>
      <path d="M270 230 q 50 0 50 60 l 0 80" fill="none" stroke={WHITE} strokeWidth={12} strokeLinecap="round" />
      <rect x={306} y={366} width={28} height={44} rx={8} fill={WHITE} />
      {/* ATM */}
      <rect x={440} y={100} width={200} height={330} rx={20} fill="#8FA5DA" />
      <rect x={460} y={125} width={160} height={110} rx={10} fill="#0B1534" />
      <text x={540} y={190} fontSize={36} fontWeight={900} fill={RED} textAnchor="middle">
        ERROR
      </text>
      {[0, 1, 2].map((r) => (
        <g key={r}>
          {[0, 1, 2].map((c) => (
            <rect key={c} x={470 + c * 52} y={255 + r * 34} width={40} height={24} rx={5} fill="#DCE7FF" />
          ))}
        </g>
      ))}
      <rect x={470} y={375} width={140} height={20} rx={8} fill="#0B1534" />
      {/* rak toko kosong */}
      <rect x={780} y={100} width={12} height={330} fill={GRAY} />
      <rect x={968} y={100} width={12} height={330} fill={GRAY} />
      {[170, 290, 410].map((y) => (
        <rect key={y} x={780} y={y} width={200} height={14} rx={4} fill={GRAY} />
      ))}
      <rect x={812} y={128} width={30} height={42} rx={6} fill={TEAL} />
      {/* tanda X */}
      {[18, 40, 62].map((delay, i) => {
        const s = pop(f, fps, delay);
        const cx = cards[i] + 272;
        return (
          <g key={delay} transform={`translate(${cx} 90) scale(${s})`}>
            <circle r={38} fill={RED} />
            <path d="M-16 -16 L16 16 M16 -16 L-16 16" stroke="#FFFFFF" strokeWidth={10} strokeLinecap="round" />
          </g>
        );
      })}
      {/* label */}
      {cards.map((x, i) => (
        <g key={`l${x}`}>
          <rect x={x + 30} y={600} width={260} height={64} rx={32} fill={YELLOW} />
          <text x={x + 160} y={645} fontSize={34} fontWeight={900} fill={NAVY} textAnchor="middle">
            {labels[i]}
          </text>
        </g>
      ))}
    </g>
  );
};

/* 6 - Kalender 30 hari */
const IllCalendar: React.FC<IllProps> = ({ d }) => {
  const f = useCurrentFrame();
  const { fps } = useVideoConfig();
  const day = Math.max(1, Math.round(interpolate(f, [8, d - 20], [1, 30], clamp)));
  const items = ["AIR", "MAKANAN", "KEAMANAN"];
  const centers = [210, 540, 870];
  return (
    <g>
      <rect x={270} y={30} width={540} height={470} rx={44} fill={WHITE} />
      <rect x={270} y={30} width={540} height={120} rx={44} fill={RED} />
      <rect x={270} y={100} width={540} height={50} fill={RED} />
      <rect x={360} y={0} width={24} height={70} rx={12} fill={GRAY} />
      <rect x={696} y={0} width={24} height={70} rx={12} fill={GRAY} />
      <text x={540} y={112} fontSize={56} fontWeight={900} fill="#FFFFFF" textAnchor="middle" letterSpacing={4}>
        HARI KE
      </text>
      <text x={540} y={400} fontSize={260} fontWeight={900} fill={NAVY} textAnchor="middle">
        {day}
      </text>
      {items.map((t, i) => {
        const s = pop(f, fps, 20 + i * 15);
        const cx = centers[i];
        return (
          <g key={t} transform={`translate(${cx} 600) scale(${s})`}>
            <rect x={-130} y={-36} width={260} height={72} rx={36} fill="none" stroke={YELLOW} strokeWidth={6} />
            <polygon points="-102,-8 -78,-8 -90,12" fill={RED} />
            <text x={14} y={12} fontSize={32} fontWeight={900} fill={YELLOW} textAnchor="middle">
              {t}
            </text>
          </g>
        );
      })}
    </g>
  );
};

/* 7 - Jaringan listrik terpisah per wilayah */
const OFF: [number, number][] = [
  [0, 0],
  [-80, -60],
  [85, -55],
  [-90, 60],
  [80, 70],
  [0, 115],
];
const EDGES: [number, number][] = [
  [0, 1],
  [0, 2],
  [0, 3],
  [0, 4],
  [0, 5],
  [1, 3],
  [2, 4],
];
const CLUSTERS = [
  { cx: 200, cy: 330, dark: true, label: "PADAM · 2019" },
  { cx: 540, cy: 400, dark: false, label: "NORMAL" },
  { cx: 880, cy: 330, dark: false, label: "NORMAL" },
];

const IllGrid: React.FC<IllProps> = () => {
  const f = useCurrentFrame();
  const { fps } = useVideoConfig();
  return (
    <g>
      {CLUSTERS.map((cl, k) => {
        const s = pop(f, fps, 6 + k * 8);
        const blink = Math.floor(f / 15) % 2 === 0 ? 1 : 0.35;
        const on = !cl.dark;
        const glow = 0.75 + 0.25 * Math.sin(f / 7 + k);
        return (
          <g key={k} transform={`translate(${cl.cx} ${cl.cy}) scale(${s})`}>
            <circle r={165} fill="none" stroke={LINE} strokeWidth={5} strokeDasharray="14 12" transform={`rotate(${f * 0.3})`} />
            {EDGES.map(([a, b], i) => (
              <line
                key={i}
                x1={OFF[a][0]}
                y1={OFF[a][1]}
                x2={OFF[b][0]}
                y2={OFF[b][1]}
                stroke={on ? YELLOW : LINE}
                strokeWidth={6}
                opacity={on ? 0.7 : 0.8}
              />
            ))}
            {OFF.map(([x, y], i) => (
              <g key={i}>
                {on ? <circle cx={x} cy={y} r={30} fill={YELLOW} opacity={0.18 * glow} /> : null}
                <circle cx={x} cy={y} r={i === 0 ? 20 : 14} fill={on ? YELLOW : cl.dark ? RED : LINE} opacity={on ? 1 : 0.25 + 0.5 * blink} />
              </g>
            ))}
          </g>
        );
      })}
      {CLUSTERS.map((cl, k) => {
        const s = pop(f, fps, 24 + k * 8);
        return (
          <g key={`p${k}`} transform={`translate(${cl.cx} 640) scale(${s})`}>
            <rect x={-150} y={-30} width={300} height={60} rx={30} fill={cl.dark ? RED : YELLOW} />
            <text x={0} y={11} fontSize={30} fontWeight={900} fill={cl.dark ? "#FFFFFF" : NAVY} textAnchor="middle">
              {cl.label}
            </text>
          </g>
        );
      })}
    </g>
  );
};

/* 8 - Ajakan komentar + follow */
const IllCta: React.FC<IllProps> = () => {
  const f = useCurrentFrame();
  const { fps } = useVideoConfig();
  const s1 = pop(f, fps, 4);
  const s2 = pop(f, fps, 24);
  const pulse = 1 + 0.04 * Math.sin(f / 6);
  return (
    <g>
      <g transform={`translate(540 190) scale(${s1})`}>
        <rect x={-300} y={-190} width={600} height={380} rx={70} fill={YELLOW} />
        <polygon points="-80,185 -140,290 20,185" fill={YELLOW} />
        <text x={0} y={95} fontSize={300} fontWeight={900} fill={NAVY} textAnchor="middle">
          ?
        </text>
      </g>
      <g transform={`translate(540 570) scale(${s2 * pulse})`}>
        <rect x={-230} y={-62} width={460} height={124} rx={62} fill={RED} />
        <text x={0} y={22} fontSize={62} fontWeight={900} fill="#FFFFFF" textAnchor="middle">
          + FOLLOW
        </text>
      </g>
      <text x={540} y={684} fontSize={46} fontWeight={900} fill={WHITE} textAnchor="middle" opacity={s2}>
        {HANDLE}
      </text>
    </g>
  );
};

const ILLS: React.FC<IllProps>[] = [IllBulb, IllStreet, IllPhone, IllKitchen, IllHospital, IllShops, IllCalendar, IllGrid, IllCta];

const SceneView: React.FC<{ scene: SceneData; index: number }> = ({ scene, index }) => {
  const f = useCurrentFrame();
  const Ill = ILLS[index];
  const isLast = index === scenes.length - 1;
  const o = isLast ? 1 : interpolate(f, [scene.duration - 8, scene.duration], [1, 0], clamp);
  return (
    <AbsoluteFill style={{ opacity: o }}>
      <Tag text={scene.tag} />
      <Stage>
        <Ill d={scene.duration} from={scene.from} />
      </Stage>
      <Caption text={scene.caption} />
    </AbsoluteFill>
  );
};

export const PowerOut: React.FC = () => (
  <AbsoluteFill style={{ fontFamily: FONT, backgroundColor: NAVY_DARK }}>
    <Background />
    <Skyline />
    {scenes.map((s, i) => (
      <Sequence key={s.id} from={s.from} durationInFrames={s.duration}>
        <SceneView scene={s} index={i} />
      </Sequence>
    ))}
    {scenes.map((s) => (
      <Sequence key={`a-${s.id}`} from={s.from + 5} durationInFrames={s.duration - 5}>
        <Audio src={staticFile(`voice/${s.id}.mp3`)} />
      </Sequence>
    ))}
    <Sequence from={Math.max(0, BLACKOUT_FRAME - 12)}>
      <Audio src={staticFile("blackout.wav")} volume={0.8} />
    </Sequence>
    <Audio
      src={staticFile("music.wav")}
      loop
      volume={(f) => interpolate(f, [0, 45, TOTAL_FRAMES - 60, TOTAL_FRAMES], [0, 0.16, 0.16, 0], clamp)}
    />
  </AbsoluteFill>
);
