import script from "./script.json";
import durations from "./durations.json";

export const FPS = 30;
export const WIDTH = 1080;
export const HEIGHT = 1920;

// Ganti dengan username akunmu (tampil di adegan penutup)
export const HANDLE = "@akunmu";

const PAD_SECONDS = 0.8; // jeda setelah narasi selesai
const LEAD_FRAMES = 5; // narasi mulai sedikit setelah adegan berganti
const MIN_SECONDS = 62; // durasi minimal video

export type SceneData = {
  id: string;
  tag: string;
  caption: string;
  narration: string;
  from: number;
  duration: number;
};

const real = durations as Record<string, number>;
const raw = script as { id: string; tag: string; caption: string; narration: string }[];

let cursor = 0;
export const scenes: SceneData[] = raw.map((s) => {
  // Sebelum voice dibuat, durasi diperkirakan dari jumlah kata
  const seconds = real[s.id] ?? s.narration.split(" ").length / 2.6;
  const duration = Math.ceil((seconds + PAD_SECONDS) * FPS) + LEAD_FRAMES;
  const scene: SceneData = { ...s, from: cursor, duration };
  cursor += duration;
  return scene;
});

const minFrames = MIN_SECONDS * FPS;
if (cursor < minFrames) {
  scenes[scenes.length - 1].duration += minFrames - cursor;
  cursor = minFrames;
}

export const TOTAL_FRAMES = cursor;
export const BLACKOUT_FRAME = scenes[1].from;
