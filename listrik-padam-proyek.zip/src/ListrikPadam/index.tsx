import React from "react";
import { Composition } from "remotion";
import { PowerOut } from "./PowerOut";
import { FPS, HEIGHT, TOTAL_FRAMES, WIDTH } from "./timeline";

export const ListrikPadamComposition: React.FC = () => (
  <Composition
    id="ListrikPadam"
    component={PowerOut}
    durationInFrames={TOTAL_FRAMES}
    fps={FPS}
    width={WIDTH}
    height={HEIGHT}
  />
);
